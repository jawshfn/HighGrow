// src/components/CurrencyDisplay.js
function CurrencyDisplay({ currency }) {
    return <h2>Currency: {currency}</h2>;
  }
  export default CurrencyDisplay;
  