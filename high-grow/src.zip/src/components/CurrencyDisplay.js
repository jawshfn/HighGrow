// src/components/CurrencyDisplay.js
function CurrencyDisplay({ currency }) {
    return <h2>${currency}</h2>;
  }
  export default CurrencyDisplay;
  