// src/constants/index.js
export const LEVEL_MULTIPLIER = 0.1;
export const UPGRADE_COST_MULTIPLIER = 1.1;
export const MILESTONE_LEVELS = [25, 50, 100];
export const plantNames = [
    'OG KUSH', 'Purple Haze', 'Sour Diesel', 'Blue Dream', 'Maui Wowie', 
    'Pineapple Express', 'White Widow', 'Northern Lights', 'Strawberry Cough', 'Lemon Haze'
  ];